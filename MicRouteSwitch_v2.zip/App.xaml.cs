
using System.Windows;

namespace MicRouteSwitch
{
    public partial class App : Application { }
}
