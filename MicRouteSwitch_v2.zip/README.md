
# MicRouteSwitch v2 (WPF, .NET 8, NAudio)

- **Fixed Alt detection**: now handles `WM_SYSKEYDOWN/UP` so Alt works reliably (including Left/Right Alt).
- **Configurable hotkey**: click **Set Hotkey**, press any key (with optional Ctrl/Shift/Alt/Win). Choose hold or toggle mode.

## How it works
- Captures your real mic (WASAPI) and plays it into **CABLE Input A** or **CABLE Input B**.
- Other apps (Application 1/Application 2) should select **CABLE Output A/B** as their microphone.

## Build
Open `MicRouteSwitch.csproj` in VS 2022 (or `dotnet build`). Requires .NET 8 and VB-CABLE installed.

## Tips
- If no CABLE devices appear, install VB-CABLE and restart the app.
- Default hotkey is **Alt** (hold). Use **Set Hotkey** to change (e.g., `Ctrl+Mouse4` not supported; keyboard only).